package com.youtuber.files;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.util.Log;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.view.WindowManager;
import android.view.Window;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.graphics.Color;
import android.view.Gravity;
import android.graphics.drawable.ColorDrawable;
import android.widget.LinearLayout;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedInputStream;

@Copyright("Copyright © 2020-2024 Xelahot-Official All Rights Reserved")
public class MainActivity extends Activity {

    private String sourceStep1Url = "https://raw.githubusercontent.com/YOUR NAME/main/STEP 1/"; //add here your STEP 1 online paks link
    private String sourceStep2Url = "https://raw.githubusercontent.com/YOUR NAME/main/STEP 2/"; //add here your STEP 2 online paks link
    private String destPath = "/storage/emulated/0/Android/data/"; //you don't need to change this
    private final String[] filesToCopy = {"game_patch_3.5.0.19364.pak", "Bypass.pak", "Headshot.pak", "Less Recoil.pak"}; //you can add more paks if you want
    private String selectedVersion = "com.tencent.ig";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.argb(255, 18, 20, 33)));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        Button btnStep1 = new Button(this);
        btnStep1.setText("STEP 1");
        Button btnStep2 = new Button(this);
        btnStep2.setText("STEP 2");

        RadioGroup radioGroup = new RadioGroup(this);
        radioGroup.setOrientation(RadioGroup.HORIZONTAL);

        String[] versions = {"GL", "KR", "VNG", "TW"};
        String[] packageNames = {"com.tencent.ig", "com.pubg.krmobile", "com.vng.pubgmobile", "com.rekoo.pubgm"};

        for (int i = 0; i < versions.length; i++) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(versions[i]);
            radioButton.setTextColor(Color.BLACK);
            radioButton.setGravity(Gravity.CENTER);

            GradientDrawable border = new GradientDrawable();
            border.setShape(GradientDrawable.RECTANGLE);
            border.setCornerRadius(22);
            border.setStroke(2, Color.argb(255, 62, 198, 122));
            border.setColor(Color.WHITE);

            StateListDrawable states = new StateListDrawable();
            GradientDrawable selectedBackground = new GradientDrawable();
            selectedBackground.setShape(GradientDrawable.RECTANGLE);
            selectedBackground.setCornerRadius(22);
            selectedBackground.setColor(Color.argb(255, 62, 198, 122));
            states.addState(new int[]{android.R.attr.state_checked}, selectedBackground);
            states.addState(new int[]{}, border);

            radioButton.setBackground(states);
            radioButton.setButtonDrawable(new ColorDrawable(Color.TRANSPARENT));
            radioButton.setPadding(16, 16, 16, 16);

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, 120);
            layoutParams.width = 300;
            layoutParams.setMargins(20, 40, 20, 40);

            radioButton.setLayoutParams(layoutParams);

            final String packageName = packageNames[i];
            radioButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        selectedVersion = packageName;
                    }
                });

            radioGroup.addView(radioButton);

            if (i == 0) {
                radioButton.setChecked(true);
            }
        }

        android.widget.LinearLayout.LayoutParams radioGroupParams = 
            new android.widget.LinearLayout.LayoutParams(
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 
            android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        radioGroupParams.gravity = Gravity.CENTER_HORIZONTAL | Gravity.TOP;
        radioGroup.setLayoutParams(radioGroupParams);

        final GradientDrawable buttonBorder = new GradientDrawable();

        btnStep1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new Thread(new Runnable() {
                            @Override
                            public void run() {
                                if (downloadFiles(sourceStep1Url)) {
                                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                openApp(selectedVersion);
                                            }
                                        }, 5000);
                                }
                            }
                        }).start();
                }
            });

        btnStep2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    new Thread(new Runnable() {
                            @Override
                            public void run() {
                                if (downloadFiles(sourceStep2Url)) {
                                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                                            @Override
                                            public void run() {
                                                openApp(selectedVersion);
                                            }
                                        }, 5000);
                                }
                            }
                        }).start();
                }
            });

        buttonBorder.setShape(GradientDrawable.RECTANGLE);
        buttonBorder.setCornerRadius(22);
        buttonBorder.setStroke(2, Color.argb(255, 62, 198, 122));
        buttonBorder.setColor(Color.argb(255, 62, 198, 122));

        btnStep1.setBackground(buttonBorder);
        btnStep2.setBackground(buttonBorder);

        btnStep1.setText("STEP 1 & 3");
        btnStep2.setText("STEP 2");
        btnStep1.setTextColor(Color.BLACK);
        btnStep2.setTextColor(Color.BLACK);

        LinearLayout.LayoutParams btnStep1Params = new LinearLayout.LayoutParams(
            580, 140);
        btnStep1Params.setMargins(20, 20, 20, 20);

        LinearLayout.LayoutParams btnStep2Params = new LinearLayout.LayoutParams(
            580, 140);
        btnStep2Params.setMargins(20, 20, 20, 20);

        btnStep1.setLayoutParams(btnStep1Params);
        btnStep2.setLayoutParams(btnStep2Params);

        LinearLayout stepButtonsLayout = new LinearLayout(this);
        stepButtonsLayout.setOrientation(LinearLayout.HORIZONTAL);
        stepButtonsLayout.setGravity(Gravity.CENTER);
        stepButtonsLayout.addView(btnStep1);
        stepButtonsLayout.addView(btnStep2);

        LinearLayout radioGroupLayout = new LinearLayout(this);
        radioGroupLayout.setOrientation(LinearLayout.VERTICAL);
        radioGroupLayout.setGravity(Gravity.CENTER);
        radioGroupLayout.addView(radioGroup);

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setGravity(android.view.Gravity.CENTER);
        layout.setPadding(16, 16, 16, 16);

        layout.addView(radioGroupLayout);
        layout.addView(stepButtonsLayout);

        setContentView(layout);
    }

    private boolean downloadFiles(String sourceUrl) {
        boolean allDownloaded = true;

        for (String fileName : filesToCopy) {
            String fileUrl = sourceUrl + fileName;
            File destination = new File(destPath + selectedVersion + "/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/", fileName);

            try {
                HttpURLConnection connection = (HttpURLConnection) new URL(fileUrl).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(10000);
                connection.setReadTimeout(10000);
                connection.connect();

                if (connection.getResponseCode() == HttpURLConnection.HTTP_OK) {
                    int fileLength = connection.getContentLength();
                    InputStream inputStream = new BufferedInputStream(connection.getInputStream());
                    FileOutputStream outputStream = new FileOutputStream(destination);

                    byte[] buffer = new byte[1024];
                    int totalRead = 0;
                    int length;

                    while ((length = inputStream.read(buffer)) > 0) {
                        totalRead += length;
                        outputStream.write(buffer, 0, length);
                    }

                    outputStream.close();
                    inputStream.close();

                    if (totalRead != fileLength) {
                        showToast("Failed to download the entire file: " + fileName);
                        allDownloaded = false;
                    }
                } else {
                    showToast("Failed to download file: " + fileName);
                    allDownloaded = false;
                }
            } catch (IOException e) {
                e.printStackTrace();
                showToast("Error downloading file: " + fileName);
                allDownloaded = false;
            }
        }

        if (allDownloaded) {
            showToast("Files have been downloaded successfully");
        }

        return allDownloaded;
    }

    private void openApp(String packageName) {
        try {
            if (getPackageManager().getPackageInfo(packageName, 0) != null) {
                Intent intent = getPackageManager().getLaunchIntentForPackage(packageName);
                if (intent != null) {
                    startActivity(intent);
                } else {
                    showToast("Unable to open the app: " + packageName);
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            showToast("App not installed: " + packageName);
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            });
    }
}

//if you share this tool please share it with the real credit @XelahotOfficial thank you all 🤎
